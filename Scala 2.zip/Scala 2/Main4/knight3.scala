// Finding a single tour on a "mega" board
//=========================================

object M4c {

// !!! Copy any function you need from file knight1.scala !!!
// !!! or knight2.scala                                   !!! 
//
// If you need any auxiliary function, feel free to 
// implement it, but do not make any changes to the
// templates below.


type Pos = (Int, Int)    // a position on a chessboard 
type Path = List[Pos]    // a path...a list of positions

// ADD YOUR CODE BELOW
//======================


//(9) 
def tour_on_mega_board(dim: Int, path: Path) : Option[Path] = {
    var res = first_tour_heuristics(dim, path)
    if(res.isDefined) return res
    for(i <- 0 until dim; j <- 0 until dim) {
        if(!path.contains((i, j))) {
            res = tour_on_mega_board(dim, path :+ (i, j))
            if(res.isDefined) return res
        }
    }
    None
}


}