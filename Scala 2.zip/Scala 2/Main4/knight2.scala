// Core Part about finding a single tour for a board using the
// Warnsdorf Rule
//==============================================================

object M4b {

// !!! Copy any function you need from file knight1.scala !!!
//
// If you need any auxiliary functions, feel free to 
// implement them, but do not make any changes to the
// templates below.

type Pos = (Int, Int)    // a position on a chessboard 
type Path = List[Pos]    // a path...a list of positions

// ADD YOUR CODE BELOW
//======================

//(6) 
def ordered_moves(dim: Int, path: Path, x: Pos) : List[Pos] = {
    legal_moves(dim, path, x).sortBy(m => legal_moves(dim, path, m).length)
}



//(7) 
def first_closed_tour_heuristics(dim: Int, path: Path) : Option[Path] = {
    if(path.length == dim*dim) {
        if(is_legal(dim, path, path.head)) return Some(path)
        else return None
    }
    for(m <- ordered_moves(dim, path, path.last)) {
        val res = first_closed_tour_heuristics(dim, path :+ m)
        if(res.isDefined) return res
    }
    None
}



//(8) Same as (7) but searches for *non-closed* tours. This 
//    version of the function will be called with dimensions of 
//    up to 30 * 30.

def first_tour_heuristics(dim: Int, path: Path) : Option[Path] = {
    if(path.length == dim*dim) return Some(path)
    for(m <- ordered_moves(dim, path, path.last)) {
        val res = first_tour_heuristics(dim, path :+ m)
        if(res.isDefined) return res
    }
    None
}




}