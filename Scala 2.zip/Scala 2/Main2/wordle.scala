// Main Part 3 about Evil Wordle
//===============================


object M2 { 

import io.Source
import scala.util._

// ADD YOUR CODE BELOW
//======================


//(1)
def get_wordle_list(url: String) : List[String] = {
    val source = Source.fromURL(url)
    val wordleList = source.getLines.mkString.split("\n").toList
    source.close()
    wordleList
}


// val secrets = get_wordle_list("https://nms.kcl.ac.uk/christian.urban/wordle.txt")
// secrets.length // => 12972
// secrets.filter(_.length != 5) // => Nil

//(2)
def removeN[A](xs: List[A], elem: A, n: Int) : List[A] = {
    if (n <= 0) xs
    else xs match {
        case Nil => Nil
        case h :: t if h == elem => removeN(t, elem, n - 1)
        case h :: t => h :: removeN(t, elem, n)
    }
}


// removeN(List(1,2,3,2,1), 3, 1)  // => List(1, 2, 2, 1)
// removeN(List(1,2,3,2,1), 2, 1)  // => List(1, 3, 2, 1)
// removeN(List(1,2,3,2,1), 1, 1)  // => List(2, 3, 2, 1)
// removeN(List(1,2,3,2,1), 0, 2)  // => List(1, 2, 3, 2, 1)

// (3)
abstract class Tip
case object Absent extends Tip
case object Present extends Tip
case object Correct extends Tip

def pool(secret: String, word: String) : List[Char] = {
    val s = secret.toList
    val w = word.toList
    val p = s.filter(c => !w.contains(c))
    p
}

def aux(secret: List[Char], word: List[Char], pool: List[Char]) : List[Tip] = {
    (secret, word) match {
        case (Nil, Nil) => Nil
        case (s :: ss, w :: ws) => 
            if(s == w) Correct :: aux(ss, ws, pool)
            else if(pool.contains(w)) Present :: aux(ss, ws, removeN(pool, w, 1))
            else Absent :: aux(ss, ws, pool)
    }
}

def score(secret: String, word: String) : List[Tip] = {
    val p = pool(secret, word)
    aux(secret.toList, word.toList, p)
}


// score("chess", "caves") // => List(Correct, Absent, Absent, Present, Correct)
// score("doses", "slide") // => List(Present, Absent, Absent, Present, Present)
// score("chess", "swiss") // => List(Absent, Absent, Absent, Correct, Correct)
// score("chess", "eexss") // => List(Present, Absent, Absent, Correct, Correct)

// (4)
def eval(t: Tip) : Int = t match {
    case Correct => 10
    case Present => 1
    case Absent => 0
}

def iscore(secret: String, word: String) : Int = {
    score(secret, word).foldLeft(0)((acc, tip) => acc + eval(tip))
}


//iscore("chess", "caves") // => 21
//iscore("chess", "swiss") // => 20

// (5)
def lowest(secrets: List[String], word: String, current: Int, acc: List[String]) : List[String] = {
    secrets match {
        case Nil => acc
        case h :: t => 
            val currentScore = iscore(h, word)
            if(currentScore < current) lowest(t, word, currentScore, List(h))
            else if(currentScore == current) lowest(t, word, current, acc :+ h)
            else lowest(t, word, current, acc)
    }
}

def evil(secrets: List[String], word: String) = {
    val initialScore = iscore(secrets.head, word)
    lowest(secrets, word, initialScore, List())
}


//evil(secrets, "stent").length
//evil(secrets, "hexes").length
//evil(secrets, "horse").length
//evil(secrets, "hoise").length
//evil(secrets, "house").length

// (6)
def frequencies(secrets: List[String]) : Map[Char, Double] = {
    val chars = secrets.mkString.toList
    val groups = chars.groupBy(identity)
    val freqs = groups.mapValues(_.size.toDouble / chars.size)
    freqs
}


// (7)
def rank(frqs: Map[Char, Double], s: String) = {
    val sortedFrqs = frqs.toList.sortBy(_._2).map(_._1)
    val ranked = s.toList.map(c => (c, sortedFrqs.indexOf(c)))
    ranked
}

def ranked_evil(secrets: List[String], word: String) = {
    val frqs = frequencies(secrets)
    rank(frqs, word)
}

