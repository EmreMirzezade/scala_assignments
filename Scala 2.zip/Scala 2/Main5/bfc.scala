// Main Part 5 about a "Compiler" for the Brainf*** language
//============================================================


object M5b {

// !!! Copy any function you need from file bf.scala !!!
//
// If you need any auxiliary function, feel free to 
// implement it, but do not make any changes to the
// templates below.


// DEBUGGING INFORMATION FOR COMPILERS!!!
//
// Compiler, even real ones, are fiendishly difficult to get
// to produce correct code. One way to debug them is to run
// example programs ``unoptimised''; and then optimised. Does
// the optimised version still produce the same result?


// for timing purposes
def time_needed[T](n: Int, code: => T) = {
  val start = System.nanoTime()
  for (i <- 0 until n) code
  val end = System.nanoTime()
  (end - start)/(n * 1.0e9)
}


type Mem = Map[Int, Int]

import io.Source
import scala.util._

// ADD YOUR CODE BELOW
//======================

// (6) 
def jtable(pg: String) : Map[Int, Int] = {
    // Initialize an empty map
    var table = Map[Int, Int]()
    // Initialize the current level and position
    var level = 0
    var pos = 0
    // Iterate through the characters of the program
    for (c <- pg) {
        c match {
            case '[' => 
                level += 1
                table += (pos -> level)
            case ']' => 
                level -= 1
                table += (pos -> level)
            case _ =>
        }
        pos += 1
    }
    table
}


// testcase
//
// jtable("""+++++[->++++++++++<]>--<+++[->>++++++++++<<]>>++<<----------[+>.>.<+<]""")
// =>  Map(69 -> 61, 5 -> 20, 60 -> 70, 27 -> 44, 43 -> 28, 19 -> 6)


def compute2(pg: String, tb: Map[Int, Int], pc: Int, mp: Int, mem: Mem) : Mem = {
    var i = pc
    var m = mp
    var mem = mem
    while (i < pg.length) {
        pg(i) match {
            case '>' => m += 1
            case '<' => m -= 1
            case '+' => mem = write(mem, m, sread(mem, m) + 1)
            case '-' => mem = write(mem, m, sread(mem, m) - 1)
	    case '.' => print(sread(mem, m).toChar)
            case ',' => mem = write(mem, m, Console.in.read.toInt)
            case '[' => if (sread(mem, m) == 0) i = tb(i)
            case ']' => if (sread(mem, m) != 0) i = tb(i)
            case _ =>
        }
	i += 1
    }
    mem
}

def run2(pg: String, m: Mem = Map()) = {
    val table = jtable(pg)
    compute2(pg, table, 0, 0, m)
}


// testcases
// time_needed(1, run2(load_bff("benchmark.bf")))
// time_needed(1, run2(load_bff("sierpinski.bf")))



// (7) 

def optimise(s: String) : String = {
    var result = ""
    var i = 0
    while (i < s.length) {
        var j = i + 1
        var count = 1
        while (j < s.length && s(j) == s(i)) {
            j += 1
            count += 1
        }
        if(s(i) == '+' || s(i) == '-') {
            if(count > 0) result += s(i) + count.toString
            else result += s(i)
        } else {
            result += s(i)
        }
        i = j
    }
    result
}


def compute3(pg: String, tb: Map[Int, Int], pc: Int, mp: Int, mem: Mem) : Mem = {
    var i = pc
    var m = mp
    var mem = mem
    while (i < pg.length) {
        pg(i) match {
            case '>' => m += 1
            case '<' => m -= 1
            case '+' => mem = write(mem, m, sread(mem, m) + 1)
            case '-' => mem = write(mem, m, sread(mem, m) - 1)
            case '.' => print(sread(mem, m).toChar)
            case ',' => mem = write(mem, m, Console.in.read.toInt)
            case '[' => if (sread(mem, m) == 0) i = tb(i)
            case ']' => if (sread(mem, m) != 0) i = tb(i)
            case _ =>
        }
        i += 1
    }
    mem
}


def run3(pg: String, m: Mem = Map()) = {
    val optimized_pg = optimise(pg)
    val table = jtable(optimized_pg)
    compute3(optimized_pg, table, 0, 0, m)
}



// testcases
//
// optimise(load_bff("benchmark.bf"))          // should have inserted 0's
// optimise(load_bff("mandelbrot.bf")).length  // => 11203
// 
// time_needed(1, run3(load_bff("benchmark.bf")))



// (8)  
def combine(s: String) : String = {
    var result = ""
    var count = 0
    for (i <- 0 until s.length) {
        if (s(i) == '+' || s(i) == '-') {
            count += s(i) match {
                case '+' => 1
                case '-' => -1
            }
        } else {
            if (count != 0) {
                result += count.toString + s(i)
                count = 0
            } else {
                result += s(i)
            }
        }
    }
    result
}


// testcase
// combine(load_bff("benchmark.bf"))


def compute4(pg: String, tb: Map[Int, Int], pc: Int, mp: Int, mem: Mem) : Mem = {
    var i = pc
    var m = mp
    var mem = mem
    while (i < pg.length) {
        pg(i) match {
            case '>' => m += 1
            case '<' => m -= 1
            case '+' => mem = write(mem, m, sread(mem, m) + (pg(i+1) - '0'))
				i += 1
			case '-' => mem = write(mem, m, sread(mem, m) - (pg(i+1) - '0'))
				i += 1
            case '.' => print(sread(mem, m).toChar)
            case ',' => mem = write(mem, m, Console.in.read.toInt)
            case '[' => if (sread(mem, m) == 0) i = tb(i)
            case ']' => if (sread(mem, m) != 0) i = tb(i)
            case _ =>
        }
        i += 1
    }
    mem
}


// should call first optimise and then combine on the input string
//
def run4(pg: String, m: Mem = Map()) : Mem = {
  // Optimize the program using the optimise function
  val optimizedPg = optimise(pg)
  // Combine the repeated adjacent commands in the program using the combine function
  val combinedPg = combine(optimizedPg)
  // Create a table that stores the matching pairs of brackets in the program
  val tb = createBracketTable(combinedPg)
  // Initialize the program counter to 0 and the memory pointer to 0
  val pc = 0
  val mp = 0
  // Call the compute4 function to start the interpreter
  compute4(combinedPg, tb, pc, mp, m)
}


// testcases
// combine(optimise(load_bff("benchmark.bf"))) // => """>A+B[<A+M>A-A]<A[[....."""

// testcases (they should now run much faster)
// time_needed(1, run4(load_bff("benchmark.bf")))
// time_needed(1, run4(load_bff("sierpinski.bf"))) 
// time_needed(1, run4(load_bff("mandelbrot.bf")))


}
