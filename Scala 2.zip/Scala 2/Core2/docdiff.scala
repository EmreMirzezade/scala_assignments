// Core Part 2 about Code Similarity
//===================================


object C2 { 

// ADD YOUR CODE BELOW
//======================

//(1)
def clean(s: String) : List[String] = ???
  
//(2)
def occurrences(xs: List[String]): Map[String, Int] = ???

//(3)
def prod(lst1: List[String], lst2: List[String]) : Int = ???

//(4)
def overlap(lst1: List[String], lst2: List[String]) : Double = ???

def similarity(s1: String, s2: String) : Double = ???