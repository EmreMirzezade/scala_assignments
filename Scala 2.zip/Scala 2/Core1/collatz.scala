// Core Part 1 about the 3n+1 conjecture
//============================================

object C1 {

// ADD YOUR CODE BELOW
//======================


//(1) 
def collatz(n: Long) : Long = ???


//(2) 
def collatz_max(bnd: Long) : (Long, Long) = ???

//(3)
def is_pow_of_two(n: Long) : Boolean = ???

def is_hard(n: Long) : Boolean = ???

def last_odd(n: Long) : Long = ???

}



// This template code is subject to copyright 
// by King's College London, 2022. Do not 
// make the template code public in any shape 
// or form, and do not exchange it with other 
// students under any circumstance.
