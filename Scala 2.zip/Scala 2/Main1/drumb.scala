// Main Part 1 about a really dumb investment strategy
//===================================================

object M1 {

//two test portfolios

val blchip_portfolio = List("GOOG", "AAPL", "MSFT", "IBM", "FB", "AMZN", "BIDU")
val rstate_portfolio = List("PLD", "PSA", "AMT", "AIV", "AVB", "BXP", "CCI", 
                            "DLR", "EQIX", "EQR", "ESS", "EXR", "FRT", "HCP") 

import io.Source
import scala.util._

// ADD YOUR CODE BELOW
//======================

import scala.io.Source

def get_january_data(symbol: String, year: Int) : List[String] = {
  val fileName = s"${symbol}.csv"
  val data = Source.fromFile(fileName).getLines.toList
  data.filter(line => line.startsWith(s"${year}-01"))
}

def get_first_price(symbol: String, year: Int) : Option[Double] = {
  val data = get_january_data(symbol, year)
  if (data.isEmpty) None
  else Some(data(0).split(",")(4).toDouble)
}

def get_prices(portfolio: List[String], years: Range) : List[List[Option[Double]]] = {
  years.map(year => portfolio.map(symbol => get_first_price(symbol, year))).toList
}

def get_delta(price_old: Option[Double], price_new: Option[Double]) : Option[Double] = {
  (price_old, price_new) match {
    case (None, _) => None
    case (_, None) => None
    case (Some(old), Some(new)) => Some((new - old) / old)
  }
}

def get_deltas(data: List[List[Option[Double]]]) :  List[List[Option[Double]]] = {
  data.zip(data.tail).map { case (row1, row2) => 
    row1.zip(row2).map { case (price1, price2) => get_delta(price1, price2) }
  }
}

def yearly_yield(data: List[List[Option[Double]]], balance: Long, index: Int) : Long = {
  data(index).map(delta => (balance * (delta.getOrElse(0.0) + 1)).toLong).sum
}

def compound_yield(data: List[List[Option[Double]]], balance: Long, index: Int) : Long = {
  if (index == 0) balance
  else compound_yield(data, yearly_yield(data, balance, index - 1), index - 1)
}

def investment(portfolio: List[String], years: Range, start_balance: Long) : Long = {
  val prices = get_prices(portfolio, years)
  val deltas = get_deltas(prices)
  compound_yield(deltas, start_balance, deltas.size - 1)
}



//Test cases for the two portfolios given above

//println("Real data: " + investment(rstate_portfolio, 1978 to 2019, 100))
//println("Blue data: " + investment(blchip_portfolio, 1978 to 2019, 100))


}




// This template code is subject to copyright 
// by King's College London, 2022. Do not 
// make the template code public in any shape 
// or form, and do not exchange it with other 
// students under any circumstance.
